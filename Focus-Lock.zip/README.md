# Focus Lock (Android App Blocker)

A lightweight, distraction-free Android app locker that blocks selected apps for a chosen duration.

## How to Build APK via GitHub Actions
1. Upload all files from this folder to a GitHub repository (`main` branch).
2. Open the **Actions** tab in your GitHub repository.
3. Once **Build Debug APK** finishes, download **Focus-Lock-APK** from the **Artifacts** section.
4. Unzip and install `app-debug.apk` on your Android tablet/phone.
