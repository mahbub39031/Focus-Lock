package com.example.focuslock

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class LockScreenActivity : AppCompatActivity() {

    private var timer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("FocusLockPrefs", Context.MODE_PRIVATE)
        val endTime = prefs.getLong("lock_end_time", 0L)
        val remainingMillis = endTime - System.currentTimeMillis()

        if (remainingMillis <= 0) {
            finish()
            return
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                goHome()
            }
        })

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0F172A"))
            setPadding(64, 64, 64, 64)
        }

        val titleText = TextView(this).apply {
            text = "ফোকাস মোড চালু আছে"
            textSize = 26f
            setTextColor(Color.parseColor("#38BDF8"))
            gravity = Gravity.CENTER
        }

        val subText = TextView(this).apply {
            text = "নির্ধারিত সময় শেষ না হওয়া পর্যন্ত এই অ্যাপটি লক করা থাকবে।"
            textSize = 16f
            setTextColor(Color.parseColor("#CBD5E1"))
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 48)
        }

        val timerText = TextView(this).apply {
            textSize = 40f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 64)
        }

        val homeBtn = Button(this).apply {
            text = "হোম স্ক্রিনে ফিরে যাও"
            setBackgroundColor(Color.parseColor("#1E293B"))
            setTextColor(Color.WHITE)
            setPadding(48, 24, 48, 24)
            setOnClickListener { goHome() }
        }

        layout.addView(titleText)
        layout.addView(subText)
        layout.addView(timerText)
        layout.addView(homeBtn)
        setContentView(layout)

        timer = object : CountDownTimer(remainingMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                val mins = (millisUntilFinished / 1000) / 60
                val secs = (millisUntilFinished / 1000) % 60
                timerText.text = String.format("%02d:%02d", mins, secs)
            }

            override fun onFinish() {
                finish()
            }
        }.start()
    }

    private fun goHome() {
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(homeIntent)
        finish()
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }
}
