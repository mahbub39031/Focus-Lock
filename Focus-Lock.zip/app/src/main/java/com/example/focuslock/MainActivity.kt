package com.example.focuslock

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.text.InputType
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val selectedPackages = mutableSetOf<String>()
    private var activeTimer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("FocusLockPrefs", Context.MODE_PRIVATE)

        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F172A"))
            setPadding(40, 48, 40, 40)
        }

        val header = TextView(this).apply {
            text = "Focus App Blocker"
            textSize = 24f
            setTextColor(Color.WHITE)
        }

        val permLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 24, 0, 24)
        }

        val accBtn = Button(this).apply {
            text = "১. Accessibility অন করো"
            textSize = 12f
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val overlayBtn = Button(this).apply {
            text = "২. Overlay পারমিশন"
            textSize = 12f
            setOnClickListener {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
        }
        permLayout.addView(accBtn)
        permLayout.addView(overlayBtn)

        val minutesInput = EditText(this).apply {
            hint = "কত মিনিট লক রাখবে? (যেমন: 60)"
            setText("60")
            inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }

        val statusText = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.parseColor("#38BDF8"))
            setPadding(0, 16, 0, 16)
        }

        val startBtn = Button(this).apply {
            text = "Start Focus Lock"
            setBackgroundColor(Color.parseColor("#0284C7"))
            setTextColor(Color.WHITE)
        }

        val scrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        val appListLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val apps = packageManager.queryIntentActivities(mainIntent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }

        val savedPackages = prefs.getStringSet("locked_packages", emptySet()) ?: emptySet()
        selectedPackages.addAll(savedPackages)

        for (resolveInfo in apps) {
            val pkg = resolveInfo.activityInfo.packageName
            val appName = resolveInfo.loadLabel(packageManager).toString()

            val checkBox = CheckBox(this).apply {
                text = appName
                setTextColor(Color.WHITE)
                isChecked = selectedPackages.contains(pkg)
                setOnCheckedChangeListener { _, isChecked ->
                    if (isChecked) selectedPackages.add(pkg)
                    else selectedPackages.remove(pkg)
                }
            }
            appListLayout.addView(checkBox)
        }
        scrollView.addView(appListLayout)

        fun updateLockUI() {
            val endTime = prefs.getLong("lock_end_time", 0L)
            val remaining = endTime - System.currentTimeMillis()

            if (remaining > 0) {
                startBtn.isEnabled = false
                minutesInput.isEnabled = false
                activeTimer?.cancel()
                activeTimer = object : CountDownTimer(remaining, 1000) {
                    override fun onTick(ms: Long) {
                        val m = (ms / 1000) / 60
                        val s = (ms / 1000) % 60
                        statusText.text = String.format("লক চালু আছে — বাকি সময়: %02d:%02d", m, s)
                    }

                    override fun onFinish() {
                        statusText.text = "লক শেষ হয়েছে!"
                        startBtn.isEnabled = true
                        minutesInput.isEnabled = true
                    }
                }.start()
            } else {
                statusText.text = "অ্যাপ সিলেক্ট করে সময় সেট করো"
                startBtn.isEnabled = true
                minutesInput.isEnabled = true
            }
        }

        startBtn.setOnClickListener {
            val mins = minutesInput.text.toString().toLongOrNull() ?: 0L
            if (selectedPackages.isEmpty()) {
                Toast.makeText(this, "কমপক্ষে একটি অ্যাপ সিলেক্ট করো!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (mins <= 0) {
                Toast.makeText(this, "সঠিক সময় দাও!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val endTime = System.currentTimeMillis() + (mins * 60_000L)
            prefs.edit()
                .putStringSet("locked_packages", selectedPackages.toSet())
                .putLong("lock_end_time", endTime)
                .apply()

            Toast.makeText(this, "$mins মিনিটের জন্য অ্যাপগুলো লক হলো!", Toast.LENGTH_SHORT).show()
            updateLockUI()
        }

        rootLayout.addView(header)
        rootLayout.addView(permLayout)
        rootLayout.addView(minutesInput)
        rootLayout.addView(statusText)
        rootLayout.addView(startBtn)
        rootLayout.addView(scrollView)

        setContentView(rootLayout)
        updateLockUI()
    }
}
