package com.example.focuslock

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class AppBlockerService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val openedPackage = event.packageName?.toString() ?: return
        if (openedPackage == packageName) return

        val prefs = getSharedPreferences("FocusLockPrefs", Context.MODE_PRIVATE)
        val endTime = prefs.getLong("lock_end_time", 0L)
        val currentTime = System.currentTimeMillis()

        if (currentTime < endTime) {
            val lockedApps = prefs.getStringSet("locked_packages", emptySet()) ?: emptySet()

            if (lockedApps.contains(openedPackage)) {
                performGlobalAction(GLOBAL_ACTION_HOME)

                val lockIntent = Intent(this, LockScreenActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                startActivity(lockIntent)
            }
        }
    }

    override fun onInterrupt() {}
}
